# Laboratorio 2: EieManager
## Implementación de la funcionalidad básica del API para client

Se creó un paquete con la jerarquía de módulos para implementar el prototipo del API.
