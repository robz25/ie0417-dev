"""
eieManager module entry point.
"""

__author__ = 'Esteban Zamora Alvarado'
__email__ = 'esteban.zamora.al@gmail.com'
__version__ = '0.0.1'
