"""
eieManager module entry point.
"""

__author__ = 'Katharina Alfaro Solís B80251'
__author__ = 'Robin González B43011'
__author__ = 'German Ureña Araya B77809'
__version__ = '0.0.1'
