"""
sensor analyzers module entry point.
"""
