import uvicorn


def main():
    uvicorn.run("eieManager.eieManager:app")


if __name__ == "__main__":
    main()
